<?php 
// Memanggil file koneksi jika diperlukan backend-nya
include 'koneksi.php'; 

// Memanggil menu sidebar yang sudah kita buat
include 'header.php'; 
?>

<div class="card-welcome">
    <h2>SELAMAT DATANG <span>RESYAN</span></h2>
    <h3>DI SISTEM INFORMASI STOK GUDANG BARANG</h3>
</div>

<?php 
// Memanggil file penutup HTML
include 'footer.php'; 
?>